CREATE TABLE Patient (
    num_patient INT PRIMARY KEY,
    nom VARCHAR(50),
    prenom VARCHAR(50),
    adresse TEXT,
    caisse_assurance VARCHAR(50)
);

CREATE TABLE Séjour (
    num_sejour INT PRIMARY KEY,
    num_patient INT,
    date_arrivee DATE,
    date_depart DATE,
    num_chambre INT,
    FOREIGN KEY (num_patient) REFERENCES Patient(num_patient),
    FOREIGN KEY (num_chambre) REFERENCES Chambre(num_chambre)
);

CREATE TABLE Chambre (
    num_chambre INT PRIMARY KEY,
    etage INT,
    service VARCHAR(50)
);

CREATE TABLE Médecin (
    code_medecin INT PRIMARY KEY,
    nom VARCHAR(50),
    prenom VARCHAR(50),
    spécialité VARCHAR(50)
);

CREATE TABLE Intervention (
    code_intervention INT PRIMARY KEY,
    date_intervention DATE,
    nom_intervention VARCHAR(100),
    num_sejour INT,
    code_medecin INT,
    FOREIGN KEY (num_sejour) REFERENCES Séjour(num_sejour),
    FOREIGN KEY (code_medecin) REFERENCES Médecin(code_medecin)
);
